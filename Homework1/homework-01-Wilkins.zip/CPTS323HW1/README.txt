Author: Michael Wilkins
Class: CPTS323
Assignment: Homework 01

.cs files included:
homework01.cs: the file that contains the Main method.
FileReader.cs: the file that contains the FileReader and INIReader classes.